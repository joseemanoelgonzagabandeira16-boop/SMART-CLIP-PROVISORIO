package ai.creatoros.smartclip

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Transformer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import android.media.MediaMetadataRetriever
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class SmartClipSuggestion(
    val platform: String,
    val title: String,
    val description: String,
    val hashtags: String,
    val startMs: Long,
    val endMs: Long,
)

object VideoAnalysisEngine {
    private data class InstructionCut(val id: String, val platform: String, val startMs: Long, val endMs: Long, val title: String, val description: String, val hashtags: String)
    private data class InstructionScript(val cutsPerPlatform: Int, val cuts: List<InstructionCut>)

    fun getCutsPerPlatform(instructions: String): Int = parseInstructionScript(instructions).cutsPerPlatform

    /** Valida o roteiro e todos os intervalos antes de qualquer análise/exportação. */
    fun validateInstructionScript(context: Context, videoUri: Uri, customInstructions: String) {
        val script = parseInstructionScript(customInstructions)
        validateScriptAgainstDuration(script, getVideoDurationMs(context, videoUri))
    }

    private fun getVideoDurationMs(context: Context, videoUri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, videoUri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?.takeIf { it > 0L }
                ?: error("Não foi possível identificar a duração do vídeo.")
        } finally {
            retriever.release()
        }
    }

    private fun validateScriptAgainstDuration(script: InstructionScript, durationMs: Long) {
        val seen = mutableSetOf<String>()
        script.cuts.forEach { instruction ->
            require(instruction.endMs - instruction.startMs >= 1000L) {
                "${instruction.id}: cada corte precisa ter pelo menos 1 segundo."
            }
            require(instruction.endMs <= durationMs) {
                "${instruction.id}: o FIM informado (${formatTimestamp(instruction.endMs)}) ultrapassa a duração do vídeo (${formatTimestamp(durationMs)})."
            }
            val signature = "${instruction.platform.lowercase(Locale.ROOT)}:${instruction.startMs}:${instruction.endMs}"
            require(seen.add(signature)) {
                "${instruction.id}: o mesmo intervalo foi repetido para a plataforma ${instruction.platform}."
            }
        }
    }

    /** Cria os cortes usando exclusivamente os horários INICIO/FIM definidos no TXT. */
    fun createLocalSuggestions(
        context: Context,
        videoUri: Uri,
        requestedDurationSeconds: Int,
        customInstructions: String
    ): List<SmartClipSuggestion> {
        val script = parseInstructionScript(customInstructions)
        val durationMs = getVideoDurationMs(context, videoUri)
        validateScriptAgainstDuration(script, durationMs)
        return script.cuts.map { instruction ->
            SmartClipSuggestion(
                platform = instruction.platform,
                title = instruction.title,
                description = "${instruction.description}\n\n${instruction.hashtags}",
                hashtags = "",
                startMs = instruction.startMs,
                endMs = instruction.endMs,
            )
        }
    }

    private fun parseTimestampToMs(value: String, fieldName: String, blockLabel: String): Long {
        val raw = value.trim()
        val numericSeconds = raw.toDoubleOrNull()
        if (numericSeconds != null) {
            require(numericSeconds.isFinite() && numericSeconds >= 0.0 &&
                numericSeconds <= Long.MAX_VALUE.toDouble() / 1000.0) {
                "$blockLabel possui $fieldName inválido ou fora do limite suportado."
            }
            return (numericSeconds * 1000.0).toLong()
        }
        val parts = raw.split(":")
        require(parts.size in 2..3) {
            "$blockLabel: $fieldName deve usar HH:MM:SS ou MM:SS (também aceita segundos decimais)."
        }
        val secondsPart = parts.last().toDoubleOrNull()
            ?: error("$blockLabel possui $fieldName inválido.")
        val minutesPart = parts[parts.size - 2].toLongOrNull()
            ?: error("$blockLabel possui $fieldName inválido.")
        val hoursPart = if (parts.size == 3) parts[0].toLongOrNull()
            ?: error("$blockLabel possui $fieldName inválido.") else 0L
        require(hoursPart >= 0L && minutesPart >= 0L &&
            (parts.size == 2 || minutesPart <= 59L) &&
            secondsPart.isFinite() && secondsPart >= 0.0 && secondsPart < 60.0) {
            "$blockLabel possui $fieldName fora do formato de horário."
        }
        val totalMilliseconds = (hoursPart * 3600.0 + minutesPart * 60.0 + secondsPart) * 1000.0
        require(totalMilliseconds.isFinite() && totalMilliseconds <= Long.MAX_VALUE.toDouble()) {
            "$blockLabel possui $fieldName fora do limite suportado."
        }
        return totalMilliseconds.toLong()
    }

    private fun formatTimestamp(milliseconds: Long): String {
        val totalSeconds = milliseconds / 1000L
        return String.format(Locale.ROOT, "%02d:%02d:%02d",
            totalSeconds / 3600L, (totalSeconds % 3600L) / 60L, totalSeconds % 60L)
    }

    private fun parseInstructionScript(instructions: String): InstructionScript {
        val text = instructions.trim()
        val countMatch = Regex("(?im)^\\s*QUANTIDADE_DE_CORTES\\s*:\\s*(\\d+)\\s*$").find(text)
            ?: error("O .TXT precisa informar QUANTIDADE_DE_CORTES: (quantidade por rede social).")
        val count = countMatch.groupValues[1].toIntOrNull()
            ?: error("A quantidade de cortes no .TXT é inválida.")
        require(count in 1..30) { "A quantidade por rede deve ficar entre 1 e 30." }

        val headers = Regex("(?im)^\\s*\\[CORTE\\s+(\\d{1,3})\\]\\s*$").findAll(text).toList()
        require(headers.size == count * 3) {
            "O .TXT declara $count cortes por rede, portanto precisa conter ${count * 3} blocos [CORTE NN]. Foram encontrados ${headers.size}."
        }
        val cuts = headers.mapIndexed { index, header ->
            val blockEnd = headers.getOrNull(index + 1)?.range?.first ?: text.length
            val block = text.substring(header.range.last + 1, blockEnd)
            val number = header.groupValues[1].toIntOrNull()
                ?: error("Identificador inválido no bloco ${index + 1}.")
            val blockLabel = "CORTE ${number.toString().padStart(2, '0')}"

            fun field(name: String): String {
                val pattern = Regex(
                    "(?ims)^\\s*$name\\s*:\\s*(.*?)(?=^\\s*(?:PLATAFORMA|INICIO|FIM|TITULO|DESCRICAO|HASHTAGS)\\s*:|\\z)"
                )
                val matches = pattern.findAll(block).toList()
                require(matches.size == 1) { "$blockLabel precisa ter exatamente um campo $name:." }
                return matches.single().groupValues[1].trim().also {
                    require(it.isNotBlank()) { "$blockLabel está com o campo $name vazio." }
                }
            }

            val platformRaw = field("PLATAFORMA")
            val platform = when (platformRaw.lowercase(Locale.ROOT).replace(" ", "")) {
                "youtube" -> "YouTube"
                "instagram" -> "Instagram"
                "tiktok" -> "TikTok"
                else -> error("$blockLabel possui plataforma inválida: $platformRaw. Use YouTube, Instagram ou TikTok.")
            }
            val startMs = parseTimestampToMs(field("INICIO"), "INICIO", blockLabel)
            val endMs = parseTimestampToMs(field("FIM"), "FIM", blockLabel)
            require(endMs > startMs) { "$blockLabel: FIM precisa ser posterior a INICIO." }
            val title = field("TITULO")
            val description = field("DESCRICAO")
            val hashtags = field("HASHTAGS")
            require(title.length <= 100) { "$blockLabel: o título deve ter no máximo 100 caracteres." }
            val descriptionWithHashtags = "$description\n\n$hashtags"
            val maxDescription = if (platform == "YouTube") 5000 else 500
            require(descriptionWithHashtags.length <= maxDescription) {
                "$blockLabel ($platform): descrição e hashtags excedem $maxDescription caracteres. Encurte o texto no .TXT."
            }

            // A numeração pode reiniciar em cada rede. O identificador interno combina plataforma e número.
            val uniqueId = "${platform.uppercase(Locale.ROOT)}_CORTE_${number.toString().padStart(2, '0')}"
            InstructionCut(uniqueId, platform, startMs, endMs, title, description, hashtags)
        }
        require(cuts.map { it.id }.distinct().size == cuts.size) {
            "Há números de corte repetidos dentro da mesma plataforma. Cada plataforma deve ter sua própria sequência sem duplicatas."
        }
        listOf("YouTube", "Instagram", "TikTok").forEach { platform ->
            val actual = cuts.count { it.platform == platform }
            require(actual == count) {
                "O .TXT precisa ter exatamente $count blocos para $platform; foram encontrados $actual."
            }
        }
        val platformOrder = listOf("YouTube", "Instagram", "TikTok")
        val orderedCuts = cuts.sortedWith(
            compareBy<InstructionCut> { platformOrder.indexOf(it.platform) }
                .thenBy { it.id.substringAfterLast("_").toIntOrNull() ?: Int.MAX_VALUE }
        )
        return InstructionScript(count, orderedCuts)
    }

    // Descobre os modelos realmente liberados para esta chave. Prioriza modelos Flash,
    // mas não descarta modelos válidos só porque seus nomes mudaram.
    private fun listGenerativeModels(apiKey: String): List<String> {
        val connection = URL("https://generativelanguage.googleapis.com/v1beta/models").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 20000
            connection.readTimeout = 30000
            connection.setRequestProperty("x-goog-api-key", apiKey)
            val code = connection.responseCode
            val response = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull().orEmpty()
                when (code) {
                    400, 401, 403 -> error("A chave Gemini foi recusada (HTTP $code). Confira a chave e as permissões da API. $detail")
                    else -> error("Não foi possível consultar os modelos Gemini (HTTP $code). $detail")
                }
            }
            val models = JSONObject(response).optJSONArray("models") ?: JSONArray()
            val available = (0 until models.length()).mapNotNull { index ->
                val item = models.optJSONObject(index) ?: return@mapNotNull null
                val methods = item.optJSONArray("supportedGenerationMethods") ?: JSONArray()
                val name = item.optString("name").removePrefix("models/")
                val supportsGenerate = (0 until methods.length()).any { methods.optString(it) == "generateContent" }
                // Gemma e modelos especializados podem aceitar texto, mas não vídeo/imagens.
                // A análise de vídeo usa quadros visuais, portanto exige um modelo Gemini.
                if (!supportsGenerate || !name.startsWith("gemini-", ignoreCase = true)) null
                else name.takeIf { it.isNotBlank() }
            }.toSet()
            return available.sortedWith(
                compareBy<String> { if (it.contains("flash", ignoreCase = true)) 0 else 1 }
                    .thenBy { if (it.contains("lite", ignoreCase = true)) 1 else 0 }
                    .thenByDescending { it }
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun errorDetail(response: String): String =
        runCatching { JSONObject(response).optJSONObject("error")?.optString("message").orEmpty() }
            .getOrDefault("").ifBlank { response.take(500) }

    private fun isUnsupportedVideoModel(detail: String): Boolean {
        val message = detail.lowercase(Locale.ROOT)
        val media = message.contains("video") || message.contains("image") || message.contains("modality")
        val unsupported = message.contains("not support") || message.contains("unsupported") ||
            message.contains("not enabled") || message.contains("doesn't support")
        return media && unsupported
    }

    private fun waitBeforeRetry(attempt: Int) {
        try {
            Thread.sleep(if (attempt == 0) 1000L else 2500L)
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            throw IllegalStateException("A conexão com o Gemini foi interrompida.", interrupted)
        }
    }

    private fun generateWithFallback(
        apiKey: String,
        body: JSONObject,
        models: List<String>,
        onModel: ((String) -> Unit)? = null
    ): Pair<String, String> {
        require(models.isNotEmpty()) {
            "A API não retornou nenhum modelo Gemini com suporte a generateContent para esta chave. Confira o acesso à API."
        }
        var lastCode = 0
        var lastResponse = ""
        for (model in models) {
            onModel?.invoke(model)
            for (attempt in 0..2) {
                val connection = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .openConnection() as HttpURLConnection
                try {
                    connection.requestMethod = "POST"
                    connection.doOutput = true
                    connection.connectTimeout = 30000
                    connection.readTimeout = 180000
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    connection.setRequestProperty("Accept", "application/json")
                    connection.setRequestProperty("x-goog-api-key", apiKey)
                    connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    lastCode = connection.responseCode
                    lastResponse = (if (lastCode in 200..299) connection.inputStream else connection.errorStream)
                        ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                } catch (network: java.io.IOException) {
                    if (attempt < 2) {
                        waitBeforeRetry(attempt)
                        continue
                    }
                    throw IllegalStateException(
                        "Falha de rede ao conectar ao Gemini. Verifique a internet e tente novamente. ${network.message.orEmpty()}",
                        network
                    )
                } finally {
                    connection.disconnect()
                }

                if (lastCode in 200..299) return model to lastResponse
                val detail = errorDetail(lastResponse)
                if (lastCode == 400) {
                    if (isUnsupportedVideoModel(detail)) break
                    error("O Google recusou os dados enviados (HTTP 400). Confira o vídeo e tente novamente. $detail")
                }
                if (lastCode == 401 || lastCode == 403) {
                    error("A chave Gemini foi recusada ou não tem permissão (HTTP $lastCode). Confira a chave e o acesso à API. $detail")
                }
                if (lastCode == 429) {
                    error("O Gemini atingiu o limite de uso (HTTP 429). Aguarde a renovação da cota antes de tentar novamente. $detail")
                }
                if (lastCode == 404) break
                if (lastCode == 408 || lastCode == 425 || lastCode == 500 ||
                    lastCode == 502 || lastCode == 503 || lastCode == 504
                ) {
                    if (attempt < 2) {
                        waitBeforeRetry(attempt)
                        continue
                    }
                    error("O Gemini está temporariamente indisponível (HTTP $lastCode). Tente novamente mais tarde. $detail")
                }
                error("Erro na comunicação com o Gemini (HTTP $lastCode). $detail")
            }
        }
        error("Nenhum dos modelos disponíveis conseguiu analisar este vídeo. Verifique a compatibilidade do modelo e tente novamente. HTTP $lastCode. ${errorDetail(lastResponse)}")
    }

    fun testConnection(apiKey: String): String {
        require(apiKey.isNotBlank()) { "Digite a chave da API Gemini." }
        val models = listGenerativeModels(apiKey)
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Responda apenas: OK")))))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 8))
        val (model, _) = generateWithFallback(apiKey, body, models)
        return "Conexão Gemini válida! A chave foi aceita e o modelo $model respondeu ao teste de texto. O envio de vídeo será validado durante uma análise."
    }

    fun analyze(context: Context, videoUri: Uri, apiKey: String, requestedCount: Int, requestedDurationSeconds: Int, customInstructions: String, onStatus: (String) -> Unit): List<SmartClipSuggestion> {
        require(apiKey.isNotBlank()) { "Adicione sua chave Gemini em Configurações > Adicionar API." }
        // Aplica os mesmos limites do modo local antes de enviar o vídeo à API.
        validateInstructionScript(context, videoUri, customInstructions)

        // Valida o acesso aos modelos antes de copiar/enviar um vídeo grande.
        // Erros de chave, permissão ou disponibilidade não desperdiçam tempo no upload.
        onStatus("Verificando disponibilidade do Gemini...")
        val availableModels = listGenerativeModels(apiKey)

        onStatus("Preparando vídeo...")
        val input = copyUriToCache(context, videoUri)
        var uploadedFileName: String? = null
        try {
            onStatus("Enviando vídeo ao Gemini...")
            val mimeType = context.contentResolver.getType(videoUri) ?: "video/mp4"
            var file = uploadVideo(input, apiKey, mimeType)
            uploadedFileName = file.optString("name").takeIf { it.isNotBlank() }
            require(uploadedFileName != null) { "O Gemini não retornou o identificador do vídeo enviado." }
            val processingStartedAt = System.nanoTime()
            var pollCount = 0
            while (file.optString("state") != "ACTIVE") {
                val state = file.optString("state").uppercase(Locale.ROOT)
                if (state == "FAILED") error("O Gemini não conseguiu processar o vídeo. Tente outro formato.")
                require(state == "PROCESSING" || state.isBlank()) {
                    "O Gemini retornou um estado inesperado para o vídeo: $state."
                }
                val elapsedSeconds = (System.nanoTime() - processingStartedAt) / 1_000_000_000L
                if (elapsedSeconds >= 600L) {
                    error("O processamento do vídeo ultrapassou 10 minutos. Tente novamente com um vídeo menor.")
                }
                pollCount++
                try {
                    Thread.sleep(if (pollCount <= 5) 2000L else 5000L)
                } catch (interrupted: InterruptedException) {
                    Thread.currentThread().interrupt()
                    error("O processamento do vídeo foi interrompido.")
                }
                file = getFile(file.getString("name"), apiKey)
                onStatus("Gemini processando vídeo... (${elapsedSeconds}s)")
            }
            onStatus("Identificando os melhores momentos...")
            return requestSuggestions(file.getString("uri"), file.optString("mimeType", mimeType), apiKey, requestedCount, requestedDurationSeconds, customInstructions, availableModels, onStatus)
        } finally {
            // Remove a cópia remota após a análise, inclusive quando ocorre erro.
            // A limpeza é best-effort e não altera o resultado principal.
            uploadedFileName?.let { name -> runCatching { deleteUploadedFile(name, apiKey) } }
            input.delete()
        }
    }

    private fun deleteUploadedFile(name: String, apiKey: String) {
        val encodedName = name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8") }
        val connection = URL("https://generativelanguage.googleapis.com/v1beta/$encodedName")
            .openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "DELETE"
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.setRequestProperty("x-goog-api-key", apiKey)
            connection.responseCode
        } finally {
            connection.disconnect()
        }
    }

    private fun copyUriToCache(context: Context, uri: Uri): File {
        val file = File.createTempFile("smartclip_input_", ".mp4", context.cacheDir)
        try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: error("Não foi possível abrir o vídeo selecionado.")
            inputStream.use { input ->
                file.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
            }
            require(file.length() > 0L) { "O vídeo selecionado está vazio." }
            return file
        } catch (error: Exception) {
            // Não deixa arquivos temporários órfãos se a leitura/cópia falhar.
            file.delete()
            throw error
        }
    }

    private fun uploadVideo(file: File, apiKey: String, mimeType: String): JSONObject {
        val start = URL("https://generativelanguage.googleapis.com/upload/v1beta/files").openConnection() as HttpURLConnection
        val uploadUrl: String
        val startCode: Int
        try {
            start.requestMethod = "POST"
            start.doOutput = true
            start.connectTimeout = 30000
            start.readTimeout = 30000
            start.setRequestProperty("X-Goog-Upload-Protocol", "resumable")
            start.setRequestProperty("X-Goog-Upload-Command", "start")
            start.setRequestProperty("X-Goog-Upload-Header-Content-Length", file.length().toString())
            start.setRequestProperty("X-Goog-Upload-Header-Content-Type", mimeType)
            start.setRequestProperty("Content-Type", "application/json")
            start.setRequestProperty("x-goog-api-key", apiKey)
            start.outputStream.use {
                it.write(JSONObject().put("file", JSONObject().put("display_name", file.name)).toString().toByteArray(Charsets.UTF_8))
            }
            uploadUrl = start.getHeaderField("X-Goog-Upload-URL") ?: start.getHeaderField("Location").orEmpty()
            startCode = start.responseCode
            if (startCode !in 200..299 || uploadUrl.isBlank()) {
                val detail = start.errorStream
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                error("Falha ao iniciar envio ao Gemini ($startCode): $detail")
            }
        } finally {
            start.disconnect()
        }

        val upload = URL(uploadUrl).openConnection() as HttpURLConnection
        try {
            upload.requestMethod = "POST"
            upload.doOutput = true
            upload.connectTimeout = 60000
            upload.readTimeout = 120000
            upload.setFixedLengthStreamingMode(file.length())
            upload.setRequestProperty("X-Goog-Upload-Offset", "0")
            upload.setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
            upload.setRequestProperty("Content-Type", mimeType)
            file.inputStream().use { input ->
                upload.outputStream.use { output -> input.copyTo(output, 64 * 1024) }
            }
            val code = upload.responseCode
            val body = (if (code in 200..299) upload.inputStream else upload.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("Falha ao enviar vídeo ao Gemini ($code): $body")
            val root = JSONObject(body)
            return root.optJSONObject("file") ?: root
        } finally {
            upload.disconnect()
        }
    }

    private fun getFile(name: String, apiKey: String): JSONObject {
        val encodedName = name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8") }
        val connection = URL("https://generativelanguage.googleapis.com/v1beta/$encodedName").openConnection() as HttpURLConnection
        connection.connectTimeout = 20000
        connection.readTimeout = 20000
        connection.setRequestProperty("x-goog-api-key", apiKey)
        val code: Int
        val body: String
        try {
            code = connection.responseCode
            body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
        } finally {
            connection.disconnect()
        }
        if (code !in 200..299) error("Erro ao consultar processamento ($code): $body")
        val root = JSONObject(body)
        return root.optJSONObject("file") ?: root
    }

    private fun requestSuggestions(fileUri: String, mimeType: String, apiKey: String, requestedCount: Int, requestedDurationSeconds: Int, customInstructions: String, models: List<String>, onStatus: (String) -> Unit): List<SmartClipSuggestion> {
        val script = parseInstructionScript(customInstructions)
        val count = script.cutsPerPlatform
        require(requestedCount == count) { "A quantidade informada não corresponde ao roteiro .TXT. Selecione o arquivo novamente." }
        val scriptForPrompt = script.cuts.joinToString("\n") { cut ->
            "${cut.id} | ${cut.platform} | INICIO: ${formatTimestamp(cut.startMs)} | FIM: ${formatTimestamp(cut.endMs)} | TÍTULO: ${cut.title} | DESCRIÇÃO: ${cut.description} | HASHTAGS: ${cut.hashtags}"
        }
        val prompt = """
            Analise visualmente os trechos indicados no roteiro .TXT, sem escolher outros momentos.
            O arquivo .TXT é a FONTE DE VERDADE para quantidade, plataforma, início, fim, título, descrição e hashtags.
            Gere exatamente $count cortes para cada plataforma, um para cada identificador listado.
            NÃO invente, reescreva, encurte, traduza ou troque os metadados. NÃO misture metadados entre cortes.
            Cada objeto JSON deve conter somente o identificador exato em cut_id e a plataforma exata em platform. Os horários do TXT são imutáveis; não sugira nem substitua horários. Não gere legendas, transcrições ou texto sobreposto.
            Mapeamento obrigatório dos blocos do TXT:
            $scriptForPrompt
            Confira se cada intervalo indicado corresponde ao conteúdo visual pretendido, mas mantenha os horários do TXT sem nenhuma alteração.
            Retorne SOMENTE JSON válido neste formato:
            {"clips":[{"cut_id":"YOUTUBE_CORTE_01","platform":"YouTube"}]}
            Inclua cada cut_id exatamente uma vez. Não inclua markdown nem texto fora do JSON.
        """.trimIndent()
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("file_data", JSONObject().put("mime_type", mimeType).put("file_uri", fileUri)))
        val content = JSONObject().put("parts", parts)
        val body = JSONObject()
            .put("contents", JSONArray().put(content))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val (_, responseText) = generateWithFallback(apiKey, body, models) { model ->
            onStatus("Tentando análise com $model...")
        }
        val response = JSONObject(responseText)
        val candidates = response.optJSONArray("candidates") ?: JSONArray()
        val candidate = candidates.optJSONObject(0)
        val generated = candidate?.optJSONObject("content")?.optJSONArray("parts")
            ?.let { parts ->
                (0 until parts.length()).mapNotNull { index ->
                    parts.optJSONObject(index)?.optString("text")?.takeIf { it.isNotBlank() }
                }.joinToString("\n")
            }.orEmpty()
        if (generated.isBlank()) {
            val blockReason = response.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            val finishReason = candidate?.optString("finishReason").orEmpty()
            error("O Gemini não retornou uma análise utilizável. ${blockReason.ifBlank { finishReason }.ifBlank { "Resposta vazia" }}")
        }
        var jsonText = generated.trim().removePrefix("```json").removePrefix("```")
            .removeSuffix("```").trim()
        val jsonStart = jsonText.indexOf('{')
        val jsonEnd = jsonText.lastIndexOf('}')
        if (jsonStart >= 0 && jsonEnd > jsonStart) jsonText = jsonText.substring(jsonStart, jsonEnd + 1)
        val clips = runCatching { JSONObject(jsonText).getJSONArray("clips") }
            .getOrElse { error("O Gemini respondeu, mas o formato dos cortes veio inválido. Tente novamente.") }

        val resultById = mutableMapOf<String, SmartClipSuggestion>()
        val expectedById = script.cuts.associateBy { it.id }
        val returnedIds = mutableSetOf<String>()
        val seen = mutableSetOf<String>()
        require(clips.length() == script.cuts.size) {
            "O Gemini retornou ${clips.length()} cortes, mas o roteiro exige ${script.cuts.size}. Nenhum metadado será preenchido ou misturado automaticamente."
        }
        for (index in 0 until clips.length()) {
            val item = clips.optJSONObject(index) ?: error("O corte ${index + 1} retornou em formato inválido.")
            val cutId = item.optString("cut_id").trim().uppercase(Locale.ROOT)
            val instruction = expectedById[cutId]
                ?: error("O Gemini retornou um identificador que não existe no .TXT: $cutId.")
            require(returnedIds.add(cutId)) { "O identificador $cutId foi retornado mais de uma vez." }
            val platformRaw = item.optString("platform").trim()
            require(platformRaw.equals(instruction.platform, ignoreCase = true)) {
                "$cutId foi associado à plataforma errada. O .TXT define ${instruction.platform}."
            }
            val startMs = instruction.startMs
            val endMs = instruction.endMs
            val signature = "${instruction.platform.lowercase(Locale.ROOT)}:$startMs:$endMs"
            require(seen.add(signature)) {
                "O Gemini repetiu o mesmo trecho em mais de um corte de ${instruction.platform}."
            }
            val descriptionWithHashtags = "${instruction.description}\n\n${instruction.hashtags}"
            resultById[cutId] = SmartClipSuggestion(
                platform = instruction.platform,
                title = instruction.title,
                description = descriptionWithHashtags,
                hashtags = "",
                startMs = startMs,
                endMs = endMs,
            )
        }
        val missing = expectedById.keys - returnedIds
        require(missing.isEmpty()) {
            "O Gemini não retornou todos os cortes do .TXT. Faltando: ${missing.joinToString(", ")}."
        }
        require(resultById.size == script.cuts.size &&
            listOf("YouTube", "Instagram", "TikTok").all { platform ->
                script.cuts.count { it.platform == platform } == count
            }
        ) { "A análise não respeitou a quantidade definida no .TXT para cada rede social." }
        // A resposta do Gemini pode vir em outra sequência; a fila final sempre
        // respeita YouTube, depois Instagram e, por último, TikTok.
        return script.cuts.map { instruction ->
            resultById[instruction.id] ?: error("O Gemini não retornou ${instruction.id}.")
        }
    }
}

@UnstableApi
object VideoCutEngine {
    fun cut(context: Context, sourceUri: Uri, suggestion: SmartClipSuggestion, index: Int): File {
        require(suggestion.startMs >= 0L && suggestion.endMs > suggestion.startMs) {
            "O corte ${index + 1} possui horários inválidos."
        }
        val output = File(
            context.cacheDir,
            "smartclip_${suggestion.platform.lowercase(Locale.ROOT)}_${index + 1}_${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(8)}.mp4"
        )
        if (output.exists()) output.delete()

        val latch = CountDownLatch(1)
        val failure = AtomicReference<Exception?>(null)
        val transformerRef = AtomicReference<Transformer?>(null)
        val mainHandler = Handler(Looper.getMainLooper())

        val startExport = Runnable {
            try {
                val clipping = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(suggestion.startMs)
                    .setEndPositionMs(suggestion.endMs)
                    .build()
                val mediaItem = MediaItem.Builder()
                    .setUri(sourceUri)
                    .setClippingConfiguration(clipping)
                    .build()
                val transformer = Transformer.Builder(context)
                    .setLooper(Looper.getMainLooper())
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(
                            composition: androidx.media3.transformer.Composition,
                            exportResult: androidx.media3.transformer.ExportResult
                        ) {
                            latch.countDown()
                        }

                        override fun onError(
                            composition: androidx.media3.transformer.Composition,
                            exportResult: androidx.media3.transformer.ExportResult,
                            exportException: androidx.media3.transformer.ExportException
                        ) {
                            failure.set(IllegalStateException(
                                "Falha ao gerar o corte ${index + 1}: ${exportException.message ?: "erro de exportação"}.",
                                exportException
                            ))
                            latch.countDown()
                        }
                    })
                    .build()
                transformerRef.set(transformer)
                transformer.start(mediaItem, output.absolutePath)
            } catch (error: Exception) {
                failure.set(error)
                latch.countDown()
            }
        }

        if (Looper.myLooper() == Looper.getMainLooper()) startExport.run()
        else check(mainHandler.post(startExport)) { "Não foi possível iniciar a exportação do corte." }

        val completed = try {
            latch.await(10, TimeUnit.MINUTES)
        } catch (interrupted: InterruptedException) {
            Thread.currentThread().interrupt()
            false
        }
        if (!completed) {
            mainHandler.post { runCatching { transformerRef.get()?.cancel() } }
            output.delete()
            throw IllegalStateException("A exportação do corte ${index + 1} foi interrompida ou excedeu o tempo limite.")
        }
        failure.get()?.let {
            output.delete()
            throw it
        }
        require(output.exists() && output.length() > 0L) {
            "O arquivo do corte ${index + 1} não foi criado corretamente."
        }
        return output
    }
}
